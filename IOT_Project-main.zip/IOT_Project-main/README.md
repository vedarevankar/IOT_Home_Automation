### INTERNSHIP PROJECT 2022
# Home automation using blynk
###### Home Automation: Garden Lights Automation using LDR sensor, Temperature Conditioner and displaying it on a Dashboard, Serial Tank automation with set of Instructions.

Created with the help of <img src="Readme\emertxe.png" alt="Emertxe logo">

###### Project Completion: 100%


***
```
Tools Used
1. Arduino IDE: IDE used to code the project
2. Picsim Lab Simulator: Simulates Arduino Uno
3. Null Emulator : Connects Picsimlab simulator to Arduino IDE
4. Blynk IOT application
```
***

Video Explaination <a href = "https://www.youtube.com/watch?v=_0EtCARlhIM"><i>here.</a>

<details>
<summary><strong>Misc Mini Learning Projects</strong></summary>
<ol>
<li> LED</li>
<li> CLCD</li>
<li> PWM</li>
</ol>
</details>


